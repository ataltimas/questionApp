//
//  questionAppApp.swift
//  questionApp
//
//  Created by scholar on 4/23/23.
//

import SwiftUI

@main
struct questionAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
